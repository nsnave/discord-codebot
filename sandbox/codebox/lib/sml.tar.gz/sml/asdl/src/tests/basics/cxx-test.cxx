/*! \file cxx-test.cxx
 *
 * \author John Reppy
 *
 * C++ test driver for basics test.
 */

/*
 * COPYRIGHT (c) 2018 The Fellowship of SML/NJ (http://www.smlnj.org)
 * All rights reserved.
 */

#include "test-spec.hxx"

int main ()
{
    return 0;
}
