Runtime support for ASDL for various languages.
