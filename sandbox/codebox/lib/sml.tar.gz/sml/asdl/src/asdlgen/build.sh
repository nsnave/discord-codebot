#!/bin/sh
#
# Copyright (c) 2018 The Fellowship of SML/NJ (https://smlnj.org)
#
# Script for SML/NJ installer to build asdlgen on Unix systems
#

make build
