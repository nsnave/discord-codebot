Test driver and files for the ASDL front end.

